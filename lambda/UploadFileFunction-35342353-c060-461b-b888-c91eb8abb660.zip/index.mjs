import { S3Client, PutObjectCommand } from '@aws-sdk/client-s3';
import { DynamoDBClient } from '@aws-sdk/client-dynamodb';
import { PutCommand, DynamoDBDocumentClient } from '@aws-sdk/lib-dynamodb';

const s3 = new S3Client();
const dynamoDBClient = DynamoDBDocumentClient.from(new DynamoDBClient());

export const handler = async (event) => {
  const bucketName = 'uploadfilejson';
  const tableName = 'uploadfiletable';

  const { fileContent, inputText, fileName } = JSON.parse(event.body);

  const s3Params = {
    Bucket: bucketName,
    Key: fileName,
    Body: Buffer.from(fileContent, 'base64'),
  };

  try {
    // Upload file to S3
    await s3.send(new PutObjectCommand(s3Params));

    // Save metadata to DynamoDB
    const dbParams = {
      TableName: tableName,
      Item: {
        id: Date.now().toString(),
        input_text: inputText,
        input_file_path: `${bucketName}/${fileName}`,
      },
    };

    await dynamoDBClient.send(new PutCommand(dbParams));

    return {
      statusCode: 200,
      body: JSON.stringify({ message: 'File uploaded and metadata saved successfully' }),
    };
  } catch (error) {
    return {
      statusCode: 500,
      body: JSON.stringify({ error: error.message }),
    };
  }
};
