import { EC2Client, RunInstancesCommand } from "@aws-sdk/client-ec2";
import { S3Client, GetObjectCommand } from "@aws-sdk/client-s3";
import { Readable } from "stream";

const ec2 = new EC2Client();
const s3 = new S3Client();

const streamToString = (stream) =>
  new Promise((resolve, reject) => {
    const chunks = [];
    stream.on("data", (chunk) => chunks.push(chunk));
    stream.on("error", reject);
    stream.on("end", () => resolve(Buffer.concat(chunks).toString("utf8")));
  });

export const handler = async (event) => {
  try {
    for (const record of event.Records) {
      if (record.eventName === "INSERT") {
        const newItem = record.dynamodb.NewImage;
        const bucketName = newItem.input_file_path.S.split("/")[0];
        const fileName = newItem.input_file_path.S.split("/")[1];
        const inputText = newItem.input_text.S;

        const s3Params = {
          Bucket: bucketName,
          Key: fileName,
        };

        const getObjectCommand = new GetObjectCommand(s3Params);
        const data = await s3.send(getObjectCommand);
        const fileContent = await streamToString(data.Body);

        // Define the user-data script to run on the EC2 instance
        const userDataScript = `#!/bin/bash
        echo "${fileContent}" > /home/ec2-user/output.txt
        echo "${inputText.length}" >> /home/ec2-user/output.txt`;

        const runInstancesCommand = new RunInstancesCommand({
          ImageId: "ami-06c68f701d8090592", // Replace with a valid AMI ID
          InstanceType: "t2.micro",
          MinCount: 1,
          MaxCount: 1,
          UserData: Buffer.from(userDataScript).toString("base64"),
        });

        await ec2.send(runInstancesCommand);
      }
    }
  } catch (error) {
    console.error("Error getting file from S3 or launching EC2:", error);
    throw error;
  }
};
